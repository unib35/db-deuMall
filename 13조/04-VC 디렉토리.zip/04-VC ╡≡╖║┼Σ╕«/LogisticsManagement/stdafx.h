#pragma once

#include <sqlda.h>
#include <sqlca.h>
#include <sqlcpr.h>